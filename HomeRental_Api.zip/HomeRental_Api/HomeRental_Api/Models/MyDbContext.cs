﻿using Microsoft.EntityFrameworkCore;

namespace HomeRental_Api.Models
{
    public class MyDbContext : DbContext
    {

        public MyDbContext(DbContextOptions<MyDbContext> options)
          : base(options) { }

        public DbSet<Property> Properties { get; set; }
        public DbSet<Favorite> Favorites { get; set; }
        public DbSet<User> Users { get; set; }

    }
}
