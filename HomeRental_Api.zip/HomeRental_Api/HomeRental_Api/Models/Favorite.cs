﻿using System.ComponentModel.DataAnnotations;

namespace HomeRental_Api.Models
{
    public class Favorite
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public int PropertyId { get; set; }

        public Property Property { get; set; }
        public User User { get; set; }
    }
}
