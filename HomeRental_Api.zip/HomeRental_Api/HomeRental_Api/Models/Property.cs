﻿using System.ComponentModel.DataAnnotations;
using HomeRental_Api.Models;

public class Property
{
    [Key]
    public int Id { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; }
    public string Location { get; set; }
    public string ImageUrl { get; set; }
    public int Bedrooms { get; set; } // Added Bedrooms
    public int Bathrooms { get; set; } // Added Bathrooms
    public string PropertyType { get; set; } // Added PropertyType

    public ICollection<Favorite> Favorites { get; set; }
}
