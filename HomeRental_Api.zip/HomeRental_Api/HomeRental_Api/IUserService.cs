﻿using HomeRental_Api.Models;

namespace HomeRental_Api
{
    public interface IUserService
    {
        Task<bool> UserExists(string username);
        Task CreateUser(User user);
        Task<User> AuthenticateUser(string username, string password);
    }
}
