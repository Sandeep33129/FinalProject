﻿using HomeRental_Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class FavoriteController : ControllerBase
{
    private readonly MyDbContext _context;

    public FavoriteController(MyDbContext context)
    {
        _context = context;
    }

    // POST: api/favorites
    [HttpPost("favorites")]
    public async Task<ActionResult> SaveFavorite(int userId, int propertyId)
    {
        var favorite = new Favorite { UserId = userId, PropertyId = propertyId };
        _context.Favorites.Add(favorite);
        await _context.SaveChangesAsync();

        return Ok();
    }

    [HttpGet("favorites/{userId}")]
    public async Task<ActionResult<IEnumerable<Property>>> GetFavorites(int userId)
    {
        var favoriteProperties = await _context.Favorites
            .Where(f => f.UserId == userId)
            .Select(f => f.Property)
            .ToListAsync();

        if (favoriteProperties == null || favoriteProperties.Count == 0)
        {
            return NotFound("No favorite properties found.");
        }

        return Ok(favoriteProperties);
    }

}
