﻿using HomeRental_Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

[Route("api/[controller]")]
[ApiController]
public class PropertyController : ControllerBase
{
    private readonly MyDbContext _context;

    public PropertyController(MyDbContext context)
    {
        _context = context;
    }

    // GET: api/properties
    [HttpGet("properties")]
    public async Task<ActionResult<IEnumerable<Property>>> GetProperties([FromQuery] PropertySearchCriteria criteria)
    {
        var query = _context.Properties.AsQueryable();

        if (!string.IsNullOrEmpty(criteria.Location))
            query = query.Where(p => p.Location.Contains(criteria.Location));

        if (criteria.MinPrice.HasValue)
            query = query.Where(p => p.Price >= criteria.MinPrice);

        if (criteria.MaxPrice.HasValue)
            query = query.Where(p => p.Price <= criteria.MaxPrice);

        if (criteria.Bedrooms.HasValue)
            query = query.Where(p => p.Bedrooms == criteria.Bedrooms);

        if (criteria.Bathrooms.HasValue)
            query = query.Where(p => p.Bathrooms == criteria.Bathrooms);

        if (!string.IsNullOrEmpty(criteria.PropertyType))
            query = query.Where(p => p.PropertyType.Contains(criteria.PropertyType));

        return await query.ToListAsync();
    }

    // POST: api/properties
    [HttpPost("properties")]
    public async Task<ActionResult<Property>> CreateProperty(Property property)
    {
        _context.Properties.Add(property);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetProperty", new { id = property.Id }, property);
    }

    // GET: api/properties/{id}
    [HttpGet("properties/{id}")]
    public async Task<ActionResult<Property>> GetProperty(int id)
    {
        var property = await _context.Properties.FindAsync(id);

        if (property == null)
        {
            return NotFound();
        }

        return property;
    }

    // PUT: api/properties/{id}
    [HttpPut("properties/{id}")]
    public async Task<IActionResult> UpdateProperty(int id, Property property)
    {
        if (id != property.Id)
        {
            return BadRequest();
        }

        _context.Entry(property).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE: api/properties/{id}
    [HttpDelete("properties/{id}")]
    public async Task<IActionResult> DeleteProperty(int id)
    {
        var property = await _context.Properties.FindAsync(id);
        if (property == null)
        {
            return NotFound();
        }

        _context.Properties.Remove(property);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
public class PropertySearchCriteria
{
    public string Location { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public int? Bedrooms { get; set; }
    public int? Bathrooms { get; set; }
    public string PropertyType { get; set; }
}
