﻿using HomeRental_Api.Models;
using HomeRental_Api;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

public class UserService : IUserService
{
    private readonly MyDbContext _context;

    public UserService(MyDbContext context)
    {
        _context = context;
    }

    public async Task<bool> UserExists(string username)
    {
        return await _context.Users.AnyAsync(u => u.Username == username);
    }

    public async Task CreateUser(User user)
    {
        // Generate salt
        var salt = new byte[16];
        using (var rng = new System.Security.Cryptography.RNGCryptoServiceProvider())
        {
            rng.GetBytes(salt);
        }

        // Hash password with salt
        var hashedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
            password: user.PasswordHash,
            salt: salt,
            prf: KeyDerivationPrf.HMACSHA256,
            iterationCount: 10000,
            numBytesRequested: 256 / 8));

        // Store the salt and hash together
        user.PasswordHash = Convert.ToBase64String(salt) + ":" + hashedPassword;
        _context.Users.Add(user);
        await _context.SaveChangesAsync();
    }

    public async Task<User> AuthenticateUser(string username, string password)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
        if (user == null || !VerifyPassword(password, user.PasswordHash))
            return null;

        return user;
    }

    private byte[] GetSaltFromStoredHash(string storedHash)
    {
        var parts = storedHash.Split(':');
        if (parts.Length != 2)
            throw new ArgumentException("Invalid stored password format");

        return Convert.FromBase64String(parts[0]); // Extract and return the salt
    }

    private bool VerifyPassword(string password, string storedHash)
    {
        // Retrieve the salt
        byte[] salt = GetSaltFromStoredHash(storedHash);

        var hashedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
            password: password,
            salt: salt,
            prf: KeyDerivationPrf.HMACSHA256,
            iterationCount: 10000,
            numBytesRequested: 256 / 8));

        // Check if the hashed password matches the stored hash
        var storedHashedPassword = storedHash.Split(':')[1];
        return storedHashedPassword == hashedPassword;
    }
}
